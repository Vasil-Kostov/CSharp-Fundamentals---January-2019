﻿namespace Heroes.Enums
{
    public enum LogType
    {
        ATTACK,
        MAGIC,
        TARGET,
        ERROR,
        EVENT
    }
}