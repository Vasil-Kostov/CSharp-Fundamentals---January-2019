﻿namespace Heroes.Contracts
{
    public interface IObserver
    {
        void Update(int value);
    }
}
