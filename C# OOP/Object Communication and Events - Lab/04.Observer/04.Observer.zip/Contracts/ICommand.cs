﻿namespace Heroes.Contracts
{
    public interface ICommand
    {
        void Execute();
    }
}
