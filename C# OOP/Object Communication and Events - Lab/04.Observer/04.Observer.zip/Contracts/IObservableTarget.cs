﻿namespace Heroes.Contracts
{
    public interface IObservableTarget : ITarget, IObserver
    {
    }
}
